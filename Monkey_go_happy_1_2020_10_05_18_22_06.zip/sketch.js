
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var ground,groundImage,g
function preload(){
  
  
  monkey_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("stone.png");
 groundImage=loadImage("jungle.jpg")
}



function setup() {
  createCanvas(800,400)
monkey=createSprite(50,350,20,20)
monkey.addAnimation("monkey",monkey_running)
  monkey.scale=0.2      
FoodGroup=new Group()
obstacleGroup=new Group()
  ground=createSprite(400,350,800,10)
ground.addImage(groundImage)
  ground.depth=monkey.depth
  monkey.depth=monkey.depth+1
g=createSprite(400,400,800,10)
g.visible=false
score=0
}


function draw() {
background("green")
  drawSprites()
bananas()
stones()
  if (keyDown("Space")){
  monkey.velocityY=-5    
  
}
if (monkey.isTouching(FoodGroup)){
  score=score+1
  FoodGroup.destroyEach()
  
}
  monkey.velocityY=monkey.velocityY+0.3  
monkey.collide(g)
textSize(25)
  fill("Red")
  text("score="+score,100,70)
}
function bananas(){
  if (frameCount%100==0){
    banana= createSprite(600,250,40,10)
    banana.addImage(bananaImage)
    banana.y=random(120,200)
    banana.velocityX=-5
    banana.lifetime=300
FoodGroup.add(banana)
  banana.scale=0.1
  }
  
}
function stones(){
  if (frameCount%150==0){
    obstacle= createSprite(600,380,40,10)
   obstacle.addImage(obstacleImage)
    obstacle.velocityX=-5
    obstacle.lifetime=300
obstacleGroup.add(obstacle)
  obstacle.scale=0.2
  }
  
}




